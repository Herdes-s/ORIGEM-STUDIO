import { useParams } from "react-router-dom";
import { getAbilityById } from "../../utils/getAbilityById";
import PageLayout from "../../components/PageLayout";

import styles from "./AbilityDetails.module.css";

function formatDuration(durationMs: number) {
  return `${durationMs / 1000}s`;
}

export default function AbilityDetails() {
  const { id } = useParams<{ id: string }>();

  const content = getAbilityById(id ?? "");

  if (!content) {
    return (
      <PageLayout
        title="Conteúdo não encontrado"
        description="Não foi possível encontrar essa habilidade ou efeito."
      />
    );
  }

  const image = content.image ?? content.iconSrc;

  return (
    <PageLayout title={content.name} description={content.description}>
      <div className={styles.details}>
        {image && (
          <div className={styles.imageContainer}>
            <img src={image} alt={content.name} />
          </div>
        )}

        <p className={styles.type}>{content.type}</p>

        {content.type === "Ativa" && (
          <section className={styles.infoSection}>
            <h2>Informações da habilidade</h2>

            <p>Dano: {content.damage ?? "Não informado"}</p>

            <p>
              Recarga:{" "}
              {content.cooldownMs != null
                ? formatDuration(content.cooldownMs)
                : "Não informado"}
            </p>

            <p>Nível necessario: {content.requiredLevel ?? "Não infromado"}</p>

            <p>Alcance: {content.range ?? "Não informado"}</p>

            <p>Distância: {content.rangeDistance ?? "Não informada"}</p>

            <p>Elemento: {content.element ?? "Não informado"}</p>

            <p>Custo de mana: {content.manaCost ?? "Não informado"}</p>

            <p>Raridade: {content.rarity ?? "Não informada"}</p>

            {content.compatibleClasses && (
              <p>Classes compatíveis: {content.compatibleClasses.join(", ")}</p>
            )}
          </section>
        )}

        {content.type === "Passiva" && (
          <section className={styles.infoSection}>
            <h2>Informações da habilidade</h2>

            <p>Raridade: {content.rarity ?? "Não informada"}</p>

            {content.passive && (
              <>
                <h3>Configurações passivas</h3>

                {content.passive.xpTrigger && (
                  <p>Gatilho: {content.passive.xpTrigger}</p>
                )}

                {content.passive.critChancePerLevel != null && (
                  <p>
                    Chance crítica por nível:{" "}
                    {content.passive.critChancePerLevel * 100}%
                  </p>
                )}

                {content.passive.critDamagePerLevel != null && (
                  <p>
                    Dano crítico por nível:{" "}
                    {content.passive.critDamagePerLevel * 100}%
                  </p>
                )}
              </>
            )}

            {content.compatibleClasses && (
              <p>Classes compatíveis: {content.compatibleClasses.join(", ")}</p>
            )}
          </section>
        )}

        {(content.type === "Positivo" || content.type === "Negativo") && (
          <section className={styles.infoSection}>
            <h2>Informações do efeito</h2>

            <p>
              Duração padrão:{" "}
              {content.duration != null
                ? formatDuration(content.duration)
                : "Não informada"}
            </p>

            {content.levels && (
              <>
                <h3>Níveis do efeito</h3>

                {content.levels.map((level, index) => (
                  <div key={index} className={styles.level}>
                    <h4>Nível {index + 1}</h4>

                    {level.durationMs != null && (
                      <p>Duração: {formatDuration(level.durationMs)}</p>
                    )}

                    {level.speedMultiplier != null && (
                      <p>
                        Multiplicador de velocidade:{" "}
                        {level.speedMultiplier * 100}%
                      </p>
                    )}

                    {level.damagePerSecond != null && (
                      <p>Dano por segundo: {level.damagePerSecond}</p>
                    )}

                    {level.damageMultiplier != null && (
                      <p>
                        Multiplicador de dano: {level.damageMultiplier * 100}%
                      </p>
                    )}
                  </div>
                ))}
              </>
            )}
          </section>
        )}
      </div>
    </PageLayout>
  );
}
